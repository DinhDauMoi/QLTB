<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tải Mã QR Code</title>
    
</head>

<body style="font-family: 'DejaVu Sans', sans-serif;">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            border: 1px solid #000 !important;
            /* giữ viền */
            padding: 5px;
            text-align: center;
            vertical-align: middle;
        }

        img {
            display: block;
            margin: 0 auto;
        }

        p {
            margin: 2px 0;
            font-size: 13px;
            line-height: 1.1;
        }

        /* Bắt Dompdf vẽ border đúng */
        table,
        tr,
        td {
            border-color: #000 !important;
            border-width: 1px !important;
            border-style: solid !important;
        }
    </style>
    <table class="table" border="1" style="border-collapse: collapse; width: 100%; text-align: center;">

        
        <tr>

            <?php $__currentLoopData = $thiet_bi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            
            
            <?php if($loop->index > 0 && $loop->index % 6 === 0): ?>
        </tr>
        <tr> 
            <?php endif; ?>

            
            <td style="padding: 5px; border: 1px solid #000; vertical-align: middle; width: 16.66%;">

                

                <div class="qr-container" style="margin-bottom: 3px;">
                    <img src="data:image/svg+xml;base64,<?php echo e(base64_encode(
                        QrCode::format('svg')
                            ->size(100)
                            ->encoding('UTF-8')
                            ->generate($item->id . '-' . $item->kho->ten_kho . '-' . $item->imei)
                    )); ?>" style="width: 100px; height: 100px;">
                    
                </div>

                <div class="info" style="line-height: 1.1; font-size: 10px; margin: 0;">
                    
                    <p style="margin: 2px 0;">Máy <?php echo e($item->id); ?> - <?php echo e($item->kho->ten_kho); ?></p>
                    <p style="margin: 2px 0;"><?php echo e($item->imei); ?></p>
                </div>

            </td>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tr>
        

    </table>
</body>

</html>
<?php echo $__env->make('fw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vinh\Desktop\QLTB\QLTB\resources\views/pdf_qr_all.blade.php ENDPATH**/ ?>